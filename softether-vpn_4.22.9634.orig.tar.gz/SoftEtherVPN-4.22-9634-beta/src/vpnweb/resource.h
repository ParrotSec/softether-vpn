//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by vpnweb.rc
//
#define IDS_PROJNAME                    100
#define IDR_VPNWEB                      101
#define IDB_VPNWEBCONTROL               102
#define IDR_VPNWEBCONTROL               103
#define IDD_VPNWEBDLG                   201
#define IDC_PROGRESS1                   201
#define P_PROGRESS                      201
#define IDI_VPN                         202
#define S_INFO                          202
#define S_INFO2                         203
#define IDC_BUTTON1                     204
#define IDI_ICON1                       204
#define IDI_SERVER                      204
#define S_ICON_VPN                      205
#define S_ICON_SERVER                   206
#define B_START                         207
#define IDS_MESSAGE_APPTITLE            10001
#define IDS_STRING10002                 10002
#define IDS_STRING10003                 10003
#define IDS_STRING10004                 10004
#define IDS_STRING10005                 10005
#define IDS_STRING10006                 10006
#define IDS_STRING10007                 10007
#define IDS_STRING10008                 10008
#define IDS_STRING10009                 10009
#define IDS_STRING10010                 10010
#define IDS_STRING10011                 10011
#define IDS_STRING10012                 10012
#define IDS_STRING10013                 10013
#define IDS_STRING10014                 10014
#define IDS_STRING10015                 10015
#define IDS_STRING10016                 10016
#define IDS_STRING10017                 10017
#define IDS_STRING10018                 10018
#define IDS_STRING10019                 10019
#define IDS_MESSAGE_APPTITLE_EN         11001
#define IDS_STRING11002                 11002
#define IDS_STRING10020                 11003
#define IDS_STRING11003                 11003
#define IDS_STRING10021                 11004
#define IDS_STRING11004                 11004
#define IDS_STRING10022                 11005
#define IDS_STRING11005                 11005
#define IDS_STRING10023                 11006
#define IDS_STRING11006                 11006
#define IDS_STRING10024                 11007
#define IDS_STRING11007                 11007
#define IDS_STRING10025                 11008
#define IDS_STRING11008                 11008
#define IDS_STRING10026                 11009
#define IDS_STRING11009                 11009
#define IDS_STRING10027                 11010
#define IDS_STRING11010                 11010
#define IDS_STRING10028                 11011
#define IDS_STRING11011                 11011
#define IDS_STRING10029                 11012
#define IDS_STRING11012                 11012
#define IDS_STRING101                   11013
#define IDS_STRING11013                 11013
#define IDS_STRING11014                 11014
#define IDS_STRING11015                 11015
#define IDS_STRING11016                 11016
#define IDS_STRING11017                 11017
#define IDS_STRING11018                 11018
#define IDS_STRING11019                 11019

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        205
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         206
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif
