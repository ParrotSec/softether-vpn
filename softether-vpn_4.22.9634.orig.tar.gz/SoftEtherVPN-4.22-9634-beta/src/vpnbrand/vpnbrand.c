#include <stdio.h>

int main()
{
	printf("VPN Branding Kit was obsolete. Customize SoftEther VPN by modifying the source code.\n");
	return 0;
}
